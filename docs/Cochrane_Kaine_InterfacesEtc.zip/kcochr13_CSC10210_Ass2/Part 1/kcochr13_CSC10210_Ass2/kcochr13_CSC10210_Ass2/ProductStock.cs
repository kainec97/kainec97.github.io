﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kcochr13_CSC10210_Ass2
{
    class ProductStock : IProduct
    {
        //integer to hold the product barcode
        private int productCode;
        //string to hold product description/name
        private string productDescription;
        //integer to hold the amount of stock left for an item
        private int productStockAmount; 
        //integer to hold the price of an item
        private int productPrice;

        //constructor for above variables
        public ProductStock(int prodno, string desc, int count, int price)
        {
            productCode = prodno;
            productDescription = desc;
            productStockAmount = count;
            productPrice = price;
        }

        //return variables 
        public int ProductType()
        {
            return productCode;
        }

        public string ProductDescription()
        {
            return productDescription;
        }

        public int ProductStockCount()
        {
            return productStockAmount;
        }

        public int ProductPrice()
        {
            return productPrice;
        }

        //print all variables in a formatted string
        public void PrintInfo()
        {
            Console.WriteLine("{0}\nDescription: {1}\nIn stock: {2}\nPrice: ${3}",
                                                                                productCode, productDescription, productStockAmount, productPrice);
            Console.ReadLine();
        }
    }
}