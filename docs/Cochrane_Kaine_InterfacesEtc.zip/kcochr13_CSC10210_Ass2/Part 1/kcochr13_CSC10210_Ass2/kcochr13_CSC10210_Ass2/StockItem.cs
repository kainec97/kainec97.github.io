﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kcochr13_CSC10210_Ass2
{
    class StockItem : Product
    {
        //string to hold supplier name
        private string supplier;
        //integer to hold barcode number for products
        private int productCode;
        //string to hold description/name for products
        private string productDescription;

        //initialise constructor which provides additional supplier string, referring to the base class for product no. and description
        public StockItem(int prodno, string desc, string s) : base(prodno, desc)
        {
            productCode = prodno;
            productDescription = desc;
            supplier = s;
        }

        //return variables
        public override int ProductType()
        {
            return productCode;
        }

        public override string ProductDescription()
        {
            return productDescription;
        }

        public string Supplier()
        {
            return supplier;
        }

        //print out supplier information based on user input
        public void PrintInfo()
        {
            Console.WriteLine("{0}\nDescription: {1}\nSupplier: {2}", productCode, productDescription, supplier);
            Console.ReadLine();
        }
    }
}