﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kcochr13_CSC10210_Ass2
{
    class ProductComparison : IProduct
    {
        //integer to hold the product barcode
        private int productCode;
        //string to hold product description/name
        private string productDescription;
        //integer to hold the amount of stock left for an item
        private int productStockAmount;
        //double to hold first price amount
        private double productPrice1;
        //double to hold second price amount (for comparison of an item)
        private double productPrice2;
        //double to hold and display the difference between the above two variables
        private double priceDifference;

        //constructor for above variables
        public ProductComparison(int prodno, string desc, int count, double price1, double price2)
        {
            productCode = prodno;
            productDescription = desc;
            productStockAmount = count;
            productPrice1 = price1;
            productPrice2 = price2;
        }

        //return variables
        public int ProductType()
        {
            return productCode;
        }

        public string ProductDescription()
        {
            return productDescription;
        }

        public int ProductStockCount()
        {
            return productStockAmount;
        }

        //method to print information to the user
        public void PrintInfo()
        {    
            //if statement for if the first price entered is less than the second price
            if (productPrice1 < productPrice2)
            {
                //calculate the price difference, set that as priceDifference variable
                priceDifference = productPrice2 - productPrice1;
                //write that the first source is cheaper if it is calculated to be. Also write the compared two prices and the price difference.
                Console.WriteLine("The price from the first source is cheaper.\n" + 
                                  "(First source: ${0} < Second source: ${1}. Price difference is: ${2}.)", productPrice2, productPrice1, priceDifference);
                Console.ReadLine();
            }

            //else if statement for if the second price is less than the first
            else if(productPrice2 < productPrice1)
            {
                //calculate the price difference, set that as priceDifference variable
                priceDifference = productPrice1 - productPrice2;
                //write that the second source is cheaper if it is calculated to be. Also write the compared two prices and the price difference.
                Console.WriteLine("The price from the second source is cheaper.\n" + 
                                  "(Second source: ${0} < First source: ${1}. Price difference is: ${2}.)", productPrice2, productPrice1, priceDifference);
                Console.ReadLine();
            }
        }
    }
}
