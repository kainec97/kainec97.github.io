﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kcochr13_CSC10210_Ass2
{
    //interface for four variables
    interface IProduct
    {
        //integer member function to hold the product barcode
        int ProductType();
        //string member function to hold the product description/name
        string ProductDescription();
        //integer member function to hold the amount of stock left for an item
        int ProductStockCount();
        //member function for printing a collection of information simultaneously
        void PrintInfo();
    }
}