﻿//Title:   Assignment 2 - Part 1
//Purpose: To demonstrate knowledge of polymorphism, abstract classes and interfaces.
//Date:    26/5/16
//Author:  Kaine Cochrane
//Version: 1.0

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kcochr13_CSC10210_Ass2
{
    class Program
    {
        static void Main()
        {
            //initialisation for two ProductStock objects
            ProductStock s = new ProductStock(19298484, "Sunglasses", 20, 15);
            ProductStock w = new ProductStock(95843205, "Watch", 5, 50);

            //initialisation for two ProductComparison objects
            ProductComparison t = new ProductComparison(44830024, "Tissues", 50, 2.50, 1.75);
            ProductComparison sh = new ProductComparison(95868578, "Shirt", 10, 15, 20);

            //initialisation for two 
            ProductDisplay p1 = new ProductDisplay(19298484, "Sunglasses", 20, 15);
            ProductDisplay p2 = new ProductDisplay(95843205, "Watch", 5, 50);

            //initialisation for StockItem object
            StockItem s1 = new StockItem(19298484, "Sunglasses", "Von Zipper");

            //call to print methods for ProductStock objects
            s.PrintInfo();
            w.PrintInfo();

            //call to print methods for ProductComparison objects
            t.PrintInfo();
            sh.PrintInfo();

            //call to print methods for ProductDisplay objects
            p1.PrintProductType();
            p1.PrintProductDescription();
            p2.PrintProductType();
            p2.PrintProductDescription();
            p1.ReturnValues();
            p2.ReturnValues();
            
            //call to print method for product supplier info
            s1.PrintInfo();
        }
    }
}