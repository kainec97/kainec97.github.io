﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kcochr13_CSC10210_Ass2
{
    //demonstration of abstract class
    abstract class Product
    {
        //definition of productCode and productDescription variables
        private int productCode;
        private string productDescription;

        //definition of abstract productType and ProductDescription classes
        public abstract int ProductType();
        public abstract string ProductDescription();

        //constructor for productCode and Description
        public Product(int prodno, string desc)
        {
            productCode = prodno;
            productDescription = desc;
        }
    }
}