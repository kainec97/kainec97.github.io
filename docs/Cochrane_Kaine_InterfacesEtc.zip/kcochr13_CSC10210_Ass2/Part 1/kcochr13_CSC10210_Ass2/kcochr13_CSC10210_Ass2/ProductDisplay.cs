﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kcochr13_CSC10210_Ass2
{
    class ProductDisplay : IProduct
    {
        //int to hold product barcode
        private int productCode;
        //string to hold description for product
        private string productDescription;
        //int to hold number of how many of a certain product are in stock
        private int productStockAmount;
        //int to hold price for items
        private int productPrice;

        //constructor for above variables
        public ProductDisplay(int prodno, string desc, int count, int price)
        {
            productCode = prodno;
            productDescription = desc;
            productStockAmount = count;
            productPrice = price;
        }

        //method to print out the product barcode/type
        public void PrintProductType()
        {
            Console.WriteLine(ProductType());
        }

        //method to print the product description/name
        public void PrintProductDescription()
        {
            Console.WriteLine(productDescription);
            Console.ReadLine();
        }

        //method to return both of the above values
        public void ReturnValues()
        {
            Console.WriteLine("{0} has a description of {1}", productCode, productDescription);
            Console.ReadLine();
        }

        //methods required by interface - only return values
        public bool ObjectCheck()
        {
            return true;
        }

        public int ProductType()
        {
            return productCode;
        }

        public string ProductDescription()
        {
            return productDescription;
        }

        public int ProductStockCount()
        {
            return productStockAmount;
        }

        public void PrintInfo()
        {
            
        }
    }
}
