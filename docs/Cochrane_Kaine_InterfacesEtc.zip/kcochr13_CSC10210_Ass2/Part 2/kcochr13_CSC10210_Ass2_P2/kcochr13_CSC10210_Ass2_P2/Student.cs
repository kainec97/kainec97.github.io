﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kcochr13_CSC10210_Ass2_P2
{
    class Student
    {
        private int StudentID;
        private string familyName;
        private string otherNames;
        private string email;

        public Student(int id, string fn, string on, string em)
        {
            StudentID = id;
            familyName = fn;
            otherNames = on;
            if (em == null)
                email = "";
            else
                email = em;
        }

        public int ID       //ID is immutable
        {
            get
            {
                return StudentID;
            }
        }

        public string FamilyName
        {
            get
            {
                return familyName;
            }
            set
            {
                familyName = value;
            }
        }

        public string OtherName
        {
            get
            {
                return otherNames;
            }
            set
            {
                otherNames = value;
            }
        }

        public string EMail
        {
            get
            {
                return email;
            }
            set
            {
                if (value == null)
                    email = "";
                else
                    email = value;
            }
        }

        public override string ToString()
        {
            return string.Format("{0}: {1}, {2}, {3}", ID, FamilyName, otherNames, EMail); ;
        }
    }
}
