﻿//Title:   Assignment 2 - Part 2
//Purpose: To demonstrate knowledge of collections (Dictionary) and LINQ.
//Date:    26/5/16
//Author:  Kaine Cochrane
//Version: 1.0

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kcochr13_CSC10210_Ass2_P2
{
    class Program
    {
        static void Main(string[] args)
        {
            //define Dictionary collection
            Dictionary<int, Student> StudentDict = new Dictionary<int, Student>();

            //Add students to Student object
            StudentDict.Add(27574114, new Student(27574114, "Rye", "Chantel", "rye.chantel1@hotmail.com"));
            StudentDict.Add(22142360, new Student(22142360, "Carter", "Kendrick", "kcarter@hotmail.com"));
            StudentDict.Add(29459958, new Student(29459958, "Faulkner", "Delia", "deliafaulkner@gmail.com"));
            StudentDict.Add(22429137, new Student(22429137, "Hughes", "Kayla", "kaylahughes@yahoo.com"));
            StudentDict.Add(21128841, new Student(21128841, "Maddison", "Roxanne", "roxanne1@yahoo.com"));
            StudentDict.Add(28046012, new Student(28046012, "Janson", "Brennan", "brennanj@outlook.com.au"));
            StudentDict.Add(24752280, new Student(24752280, "Shaw", "Cori", "corishaw@gmail.com"));
            StudentDict.Add(24642678, new Student(24642678, "Bardsley", "Porter", "porterb@yahoo.com"));
            StudentDict.Add(26683433, new Student(26683433, "Tyson", "Katherina", "kathty@gmail.com"));
            StudentDict.Add(25127651, new Student(25127651, "Patton", "Shane", "shanepatton2@gmail.com"));
            StudentDict.Add(25655552, new Student(25655552, "Thomas", "Liliana", "lilithomas@hotmail.com"));


            //Print all data from the Dictionary
            //LINQ statement to set variable for student data (later used in foreach statement)
            var allData =
                from a in StudentDict
                select a;

            Console.WriteLine("All student data:\n");
            //foreach statement to display all student data
            foreach(var a in allData)
            {
                Console.WriteLine("{0}", a);
            }
            Console.ReadLine();


            //Prompt user to select entry to remove from collection
            Console.WriteLine("Please enter an entry to remove.");
            string removeString = Console.ReadLine();
            //if statement to remove user entered key if it exists, otherwise error displays message to user    
            if (StudentDict.ContainsKey(Convert.ToInt32(removeString)))
            {
                StudentDict.Remove(Convert.ToInt32(removeString));
                Console.WriteLine("Key was successfully removed.");
                Console.ReadLine();
            }
            else
            {
                Console.WriteLine("Key could not be found. No key removed.");
                Console.ReadLine();
            }


            //Prompt user to enter ID, then display information for that ID
            int checkKey;
            Console.WriteLine("Please enter the student ID you wish to view information for.");
            checkKey = Convert.ToInt32(Console.ReadLine());
            if (StudentDict.ContainsKey(checkKey))
            {
                Console.WriteLine(StudentDict[checkKey]);
                Console.ReadLine();
            }
            else
            {
                Console.WriteLine("Key was not found.");
                Console.ReadLine();
            }
            

            //Sort all keys in the Dictionary in ascending order
            //LINQ statement to set the keys to ascending order
            var ascIDSort =
                from so in StudentDict.Keys
                orderby so ascending
                select so;

            Console.WriteLine("Sorted ID keys:\n");
            //Foreach loop to write sorted keys to console
            foreach (var so in ascIDSort)
            {
                Console.WriteLine(so);
            }
            Console.ReadLine();


            //Sort all family names for the students in ascending order
            var ascFNSort =
                from fns in StudentDict.Values
                let lowerCase = fns.FamilyName.ToLower()
                orderby lowerCase
                select fns;

            Console.WriteLine("Family names sorted in ascending order:\n");
            //Foreach loop to write ascending family names to console
            foreach (var fns in ascFNSort)
            {
                Console.WriteLine(fns);
            }
            Console.ReadLine();


            //Display all family names from m through s
            var MThroughS =
                from mts in StudentDict.Values
                let lowerCase = mts.FamilyName.ToLower()
                where lowerCase.StartsWith("m") || lowerCase.StartsWith("n") || lowerCase.StartsWith("o") || lowerCase.StartsWith("p") 
                                                || lowerCase.StartsWith("q") || lowerCase.StartsWith("r") || lowerCase.StartsWith("s")
                select lowerCase;

            Console.WriteLine("\nFamily names 'm' through 's':\n");
            //Foreach loop to write family names 'm' through 's' to console
            foreach (var mts in MThroughS)
            {
                Console.WriteLine(mts + "\n");
            }
            Console.ReadLine();


            //Foreach loop to display each student's IDs and associated email address
            Console.WriteLine("Student IDs with their associated email addresses:\n");
            foreach (var fns in ascFNSort)
            {
                Console.WriteLine("{0}, {1}", fns.ID, fns.EMail);
            }
            Console.ReadLine();
        }
    }
}